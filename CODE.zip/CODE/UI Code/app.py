from flask import Flask,render_template,url_for,request
import glob
import pandas as pd
import numpy as np
from nltk.corpus import stopwords
import matplotlib.pyplot as plt
import nltk
from nltk.util import ngrams
from collections import Counter
import matplotlib.pyplot as plt
from nltk.text import Text
from nltk.stem import WordNetLemmatizer
from sklearn import model_selection, naive_bayes, svm
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.metrics import accuracy_score

import gensim
import gensim.corpora as corpora
from gensim.utils import simple_preprocess
from gensim.models import CoherenceModel
import pyLDAvis
import pyLDAvis.gensim
import pickle



app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')


#@app.route('/predict',methods=['POST'])
@app.route('/predict', methods=['GET', 'POST']) 

def predict():
    df= pd.read_csv("classidoc.csv", encoding="latin-1")
    
    from sklearn.feature_extraction.text import TfidfVectorizer
    v = TfidfVectorizer()
    x2 = v.fit_transform(df['preprocessed'].apply(lambda x:np.str_(x)))
    y2=df['Labels']
    
    X_train,X_test,Y_train,Y_test=train_test_split(x2,y2,test_size=0.2,random_state=10)
    NB=MultinomialNB().fit(X_train,Y_train)
    y2_pred=NB.predict(X_test)
    score=metrics.accuracy_score(Y_test,y2_pred)
    
    if request.method == 'POST':
        preprocessed = request.form['preprocessed']
        data = [preprocessed]
        vect = v.transform(data).toarray()
        my_prediction = NB.predict(vect)
        prob=NB.predict_proba(vect)[0]
        probability=prob[0]
        print(my_prediction)
        print(probability)
    return render_template('result.html',preprocessed= my_prediction,probab= probability)
        
if __name__ == '__main__':
    app.run(debug=True)




